# Conditions
Macro - 10x objective. Aperture 2.
Micro - 40x objective. Aperture 5.
Polarized had polarizer in. Normal had no polarizer. Both had no analyzer in.
These measurements were performed on sample 5 (.0019 g BrDPA-AzoBipy
.0003 g Damar Gum,
13.6 wt% damar gum,
21 periods for 161 µm = 3 µm pitch)


