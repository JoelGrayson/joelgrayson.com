{ 
    // Tokens - punctuation or word
    <curr_token>: {
        "$count": number, //total count
        <next_token>: <freq>, //number of times current letter goes to this next letter (later divided by $count)
        ...
    },
    ...
}
