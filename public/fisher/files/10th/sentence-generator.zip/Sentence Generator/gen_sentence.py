import random
from get_probs import not_end_punctuation
import numpy as np
from nltk.tokenize.treebank import TreebankWordDetokenizer

def gen_sentence(probs):
    tokens=[]

    # Get first word
    first_token='.'
    while not not_end_punctuation(first_token): #keep generating until not an end punctuation
        first_token=random.choice(list(dict.keys(probs)))
    token=first_token #current token


    while not_end_punctuation(token): #before hitting the end
        tokens.append(token)
        next_token_choices=list(dict.keys(probs[token]))
        next_token_probs=list(dict.values(probs[token]))

        token=np.random.choice(next_token_choices, p=next_token_probs) #set to next token
    
    tokens.append(token) #add end punctuation as last token

    sentence=TreebankWordDetokenizer().detokenize(tokens) #arr of tokens -> readable string
    sentence=sentence[0].upper()+sentence[1:] #uppercase first letter
    return sentence
