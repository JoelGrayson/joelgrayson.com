from gen_sentence import gen_sentence
from get_probs import get_probs
import math
import random

def gen_sentences(num_words):
    probs=get_probs('./corpi/brown.txt')
    for i in range(num_words):
        print(gen_sentence(probs))

def gen_term_paper(num_paragraphs=10):
    probs=get_probs("./corpi/China's Brutal Road to Socialism.txt")
    paragraphs=[]
    for i in range(num_paragraphs): # 3 paragraphs
        lines=[]
        for j in range(4+math.floor(random.random()*6)): #4-10 sentences per paragraph
            lines.append(gen_sentence(probs))
        paragraphs.append(' '.join(lines))

    print('\t'+'\n\t'.join(paragraphs))

# gen_sentences(10)
gen_term_paper()
