import nltk

def get_probs(filename):
    return divide(
        count_instances(
            get_contents(filename)
        )
    )

def get_contents(filename): #filename -> an array of words
    with open(filename) as f:
        contents=f.read()
        return nltk.word_tokenize(contents) #split by words

def not_end_punctuation(token):
    return token not in ['.', '!', '?', '$end']

def count_instances(contents):
    # See probs in `schemas.md`
    probs={}
    
    # Count all the token occurrences
    for i, token in enumerate(contents): #token can be word or punctuation
        next_token='$end'
        if not_end_punctuation(token): #not end of sentence
            next_token=contents[i+1]

        if token not in probs: #new token
            probs[token]={
                "$count": 1,
                next_token: 1
            }
        else:
            probs[token]['$count']+=1 #increase total count
            if next_token not in probs[token]: #new next token
                probs[token][next_token]=1
            elif next_token in probs[token]: #next token already there
                probs[token][next_token]+=1

    return probs

def divide(schema): #process the count to frequency
    # print('schema', schema)
    out={} #output schema
    for token in schema:
        count=schema[token]['$count']
        out[token]={} #next tokens
        for next_token in schema[token]:
            if next_token=='$count': #skip special var
                continue
            freq=schema[token][next_token]
            out[token][next_token]=freq/count
        if out[token]=={}: #if no next tokens, only end
            out[token]={ '$end': 1 }
    return out


if __name__ == '__main__':
    get_probs('./corpi/test.txt')
