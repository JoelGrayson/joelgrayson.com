x=0
while x<3:
    print(x)
    for i in range(3):
        break
    x+=1