def insertion_sort(lst):
    for i in range(len(lst)):
        current=lst[i]
        j=i
        while j>0 and lst[j-1]>current:
            lst[j]=lst[j-1] #shift <<
            j-=1
        
        lst[j]=current

sordid=[3, 6, -1, -3]
print(sordid)
insertion_sort(sordid)
print(sordid)