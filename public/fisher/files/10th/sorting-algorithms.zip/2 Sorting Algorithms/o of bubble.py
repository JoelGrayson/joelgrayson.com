import numpy as np
from numpy.core.arrayprint import format_float_scientific
from bubble_sort import even_better_bubble_sort as bubble_sort

size=100
best=np.arange(size, 0, 1)
random=np.random.randint(1, size, size=size)
worst=np.arange(size, 0, -1)
print(bubble_sort(best)[0])
print(bubble_sort(random)[0])
print(bubble_sort(worst)[0])
print(random)
random.sort()
print(random)