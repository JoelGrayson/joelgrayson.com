'''
O(N^2)

for each pass through:
    loop through list:
        compare & swap with larger on right
'''

def bubble_sort(u_list): #basic
    n_list=u_list.copy() #new list
    commands=0
    for m_pass in n_list:
        for lower_i in range(len(n_list)-1): #compares lower_index with higher_index, so len list -1
            commands+=1
            higher_i=lower_i+1
            if n_list[lower_i]>n_list[higher_i]:
                n_list[lower_i], n_list[higher_i]=n_list[higher_i], n_list[lower_i]
    return (commands, u_list)

def better_bubble_sort(u_list): #triangle, 50% better
    commands=0
    for i in range(len(u_list)-1):
        for lower_i in range(len(u_list)-(i+1)): #compares lower_index with higher_index, so len list -1
            commands+=1
            higher_i=lower_i+1
            if u_list[lower_i]>u_list[higher_i]:
                buffer=u_list[lower_i]
                u_list[lower_i]=u_list[higher_i]
                u_list[higher_i]=buffer
    return (commands, u_list)

def even_better_bubble_sort(u_list): #triangle & returns when no swap
    commands=0
    for i in range(len(u_list)-1):
        for lower_i in range(len(u_list)-(i+1)): #compares lower_index with higher_index, so len list -1
            didSwap=False
            commands+=1
            higher_i=lower_i+1
            if u_list[lower_i]>u_list[higher_i]:#swap
                didSwap=True
                buffer=u_list[lower_i]
                u_list[lower_i]=u_list[higher_i]
                u_list[higher_i]=buffer
            if not didSwap: #no swaps, therefore list in order
                break
    return (commands, u_list)

def compareThreeOperators(lst):
    print('Sorted:', even_better_bubble_sort(lst)[1])
    print('Bubble:', bubble_sort(lst)[0])
    print('Better:', better_bubble_sort(lst)[0])
    print('Even Better:', even_better_bubble_sort(lst)[0])

if __name__=='__main__':
    compareThreeOperators([3, 1, 6, 3, 2, 8, 9, 4])
