import numpy as np

list_size=5000
sorted=np.arange(list_size) #best
reverse=np.arange(list_size-1, -1, -1) #worst
random=np.floor(np.random.rand(list_size)*list_size) #random integers from 0-list_size (array size list_size)

from bubble_sort import even_better_bubble_sort as bubble_sort
from selection_sort import selection_sort
from insertion_sort import insertion_sort
from bucket_sort import bucket_sort

def sortedReverseRandom(sort_func):
    # sort_func(sorted)
    # sort_func(reverse)
    # sort_func(random)
    sort_func([.000000001, .00000001, .0000001, .000001, .1, 1, 10, 100, 1000, 10000, 100000, 1000000])

sortedReverseRandom(bucket_sort)

"""
# Results (average of 3 tests)
*Sort Method*   *All*   *Worst*   *Best*   *Random*
Bubble Sort     ~4.8s     5s       0.4s       0.4s
Selection Sort  ~5.1s     2.1s     2.1s       2.5s
Insertion Sort  ~4s       1.5s     0.3s       1.9s
Bucket Sort     ~.7s
"""