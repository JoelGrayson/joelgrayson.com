def insertion_sort(lst):
    for i in range(1, len(lst)): #check all but first
        current=lst[i]
        j=i #index for comparison
        while lst[j-1]>current and j>0: #shift over j-1 -right-> j while before is greater & not last item
            lst[j]=lst[j-1]
            j-=1
        
        lst[j]=current #insert after position met
    return lst

if __name__ == '__main__':
    print(insertion_sort([8, 2, -3, 5]))