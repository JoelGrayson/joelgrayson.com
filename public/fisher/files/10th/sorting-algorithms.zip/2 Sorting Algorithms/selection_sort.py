import numpy as np

def selection_sort_do_not_use(lst): #bad because `del` is too CPU intensive
    output=[]
    while len(lst)>0:
        smallest_i=0
        for i, num in enumerate(lst): #go through list to find index of smallest number
            if num<lst[smallest_i]:
                smallest_i=i
        print(f"Smallest is {lst[i]}")
        output.append(lst[i])
        del lst[i] #remove item from list
    return output

def selection_sort(lst): #only uses one list
    #sorted_i — number of items that have already been sorted at the beginning of the list
    for sorted_i in range(len(lst)-1): #when one item left over, everything in order
        smallest_i=sorted_i
        #Find smallest_i
        for j in range(sorted_i, len(lst)):
            if (lst[j] < lst[smallest_i]): #index j has smaller item than smallest_i, so new smallest index
                smallest_i=j
        #Swap
        lst[sorted_i], lst[smallest_i]=lst[smallest_i], lst[sorted_i]

    return lst

def selection_sort_comparisons(lst, **no_print): #only uses one list
    if not no_print:
        print('Original: ', lst)
    #sorted_i — number of items that have already been sorted at the beginning of the list
    comparisons=0
    swaps=0
    for sorted_i in range(len(lst)-1): #when one item left over, everything in order
        smallest_i=sorted_i
        #Find smallest_i
        for j in range(sorted_i, len(lst)):
            comparisons+=1
            if (lst[j] < lst[smallest_i]): #index j has smaller item than smallest_i, so new smallest index
                swaps+=1
                smallest_i=j
        #Swap
        lst[sorted_i], lst[smallest_i]=lst[smallest_i], lst[sorted_i]
    if not no_print:
        print(f'Comparisons: {comparisons}, Swaps: {swaps}')
    return (lst, comparisons, swaps) 


if __name__=='__main__':
    selection_sort_comparisons([1, 2, 3, 4]) #best
    selection_sort_comparisons([1, 3, 4, 2]) #average
    selection_sort_comparisons([4, 3, 2, 1]) #worst
    #Finding a pattern in how many comparisons and swaps are needed for lists
    print('\nSize\tComparisons\tSwaps') #Column Headers
    for i in range(10):
        random_list=np.random.rand(i)
        lst, comparisons, swaps=selection_sort_comparisons(random_list, no_print=True)
        print(f'{i}\t{comparisons}\t\t{swaps}')
