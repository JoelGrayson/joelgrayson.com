from testing import *

demo()
# test_all()
# high_collisions()
# has_test()
# keys_values_test()
