def get_probs(filename):
    return divide(
        count_instances(
            get_contents(filename)
        )
    )

def get_contents(filename): #filename -> an array of words
    with open(filename) as f:
        contents=f.read()
        return contents.split()

def count_instances(contents):
    # See probs in `schemas.md`
    probs={}
    
    # Count all the letter occurrences
    for word in contents:
        word=f'^{word}$'.lower() #process word by adding start and end
        for i, letter in enumerate(word):
            next_letter=''
            if letter!='$': #not last char
                next_letter=word[i+1]

            if letter not in probs: #new letter
                probs[letter]={
                    "$count": 1,
                    next_letter: 1
                }
            else: #modify letter
                probs[letter]['$count']+=1 #total count
                if next_letter not in probs[letter]: #new next letter
                    probs[letter][next_letter]=1 #freq of 1
                elif next_letter in probs[letter]: #letter already there
                    probs[letter][next_letter]+=1 #increase freq            
    return probs

def divide(schema): #process the count to frequency
    # print('schema', schema)
    out={} #output schema
    for letter in schema:
        count=schema[letter]['$count']
        out[letter]={} #next letters
        for next_letter in schema[letter]:
            if next_letter=='$count': #skip special var
                continue
            freq=schema[letter][next_letter]
            out[letter][next_letter]=freq/count
        if out[letter]=={}: #if no next letter, only end
            out[letter]={ '$': 1 }
    #  print(out)
    return out


if __name__ == '__main__':
    get_probs('./corpi/test.txt')
