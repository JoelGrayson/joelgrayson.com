{ 
    // Letters
    <curr_letter>: {
        "$count": number, //total count
        <next_letter>: <freq>, //number of times current letter goes to this next letter (later divided by $count)
        ...
    },
    ...
}
