Schema
[
    //Letters
    {
        from: any, //eg 'a'
        total: number,
        to: [
            {
                value: any,
                frequency: number //number of times it goes to this value
            },
            ...
        ]
    },
    ...
]