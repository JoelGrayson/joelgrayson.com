from get_probs import get_probs
import numpy as np

def gen_random_word(probs):
    word=''
    letter='^' #first letter

    while letter!='$': #before hitting the end
        if letter!='^' and letter!='$': #not a special char
            word+=letter
        
        next_letter_choices=list(dict.keys(probs[letter]))
        next_letter_probs=list(dict.values(probs[letter]))
                    
        letter=np.random.choice(next_letter_choices, p=next_letter_probs) #set to next letter
    
    return word

def gen_words(num_words):
    probs=get_probs('./corpi/brown.txt')
    # probs=get_probs("./corpi/China's Brutal Road to Socialism.txt")
    for i in range(num_words):
        print(gen_random_word(probs))

if __name__ == '__main__':
    gen_words(20)
