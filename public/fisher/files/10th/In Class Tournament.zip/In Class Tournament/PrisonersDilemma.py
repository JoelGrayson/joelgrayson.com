import random
import numpy as np
import sys
import time


import FisherStrategies as fs
from strats import pdKimberly
from strats import pdDaniel
from strats import pdOliver
from strats import pdJoel
from strats import pdAlex
from strats import pdTopkis
from strats import pdDiane
from strats import pdDavid


#IMPORT YOUR FILE HERE


"""
For all Strategies,
 return True for cooperate, 
 return False for defect

"""

ROUND = 1

class Tournament():
	def __init__(self, strats):
		self.numCompetitors = len(strats)
		self.strats = strats
		self.gameScores = np.zeros((self.numCompetitors, self.numCompetitors))
		self.scoreBoard = np.zeros(self.numCompetitors)
		self.N = random.randint(500,1500)
		
		print(self.N)
		self.matchups = []

		#Create all possible matchups
		for i in range(self.numCompetitors):
			for j in range(i,self.numCompetitors):
				self.matchups.append((i,j))

		random.shuffle(self.matchups)

	#run a matchup. s1 and s2 are indices in the list of all strategies
	def playGame(self,s1, s2):
		strat1 = self.strats[s1] # get strategy objects
		strat2 = self.strats[s2]
		score1 = 0
		score2 = 0
		mvs1 = []
		mvs2 = []
		for i in range(self.N):
			mv1 = strat1.getMove(mvs1, mvs2) #call each strat's getMove with the move histories
			mv2 = strat2.getMove(mvs2, mvs1)

			if mv1 not in [False, True]:
				raise Exception(f"{strat1.getName()} returned invalid move: {mv1}")
			if mv2 not in [False, True]:
				raise Exception(f"{strat2.getName()} returned invalid move: {mv2}")
			scores = self.playRound(mv1, mv2)

			score1 += scores[0] #update running scores
			score2 += scores[1]
			mvs1.append(mv1) 	#update move histories
			mvs2.append(mv2)

		self.scoreBoard[s1] += score1
		self.scoreBoard[s2] += score2
		self.gameScores[s1,s2] = score1
		self.gameScores[s2,s1] = score2
		self.log(strat1, strat2, mvs1, mvs2, score1, score2)
		print(strat1.getName() + ": " + str(score1),strat2.getName() + ": " + str(score2) )

	#get payoff results of a round give the two moves
	def playRound(self,mv1, mv2):
		if mv1 and mv2: #Both Cooperate
			return (3, 3)
		elif mv1: #Player1 coops and player2 defects
			return (0, 5)
		elif mv2: #Player1 defects and player2 coops
			return (5, 0)
		else: #Both defect
			return (1, 1)

	#run each matchup
	def runTournament(self):
		for (s1, s2) in self.matchups:
			print ("playing: " + self.strats[s1].getName() + ", " + self.strats[s2].getName())
			time.sleep(.5)
			self.playGame(s1,s2)
			input()
		self.displayResults()
		#print (self.gameScores)
		#print([self.strats[i].getName() + ": " + str(self.scoreBoard[i]) for i in range(self.numCompetitors)])
	
	#print final scores of each strategy to the console 
	def displayResults(self):
		res = [(self.scoreBoard[i],self.strats[i].getName()) for i in range(self.numCompetitors)]
		res.sort()
		res.reverse()
		print("\nRESULTS")
		for player in res:
			print(player[1] + ": " + str(player[0]))

	#Write the results of a matchup to a file
	def log(self, strat1, strat2, mvs1, mvs2, score1, score2):
		f = open("results/" + strat1.getName() + strat2.getName() + "_round" + str(ROUND), 'w')
		#names
		f.write("\t{0:>20s}\t{1:>20s}\n".format(strat1.getName(), strat2.getName()))
		f.write("-"*52+"\n")
		#moves of each round
		for i in range(len(mvs1)):
			if mvs1[i] == True:
				s1 = "COOPERATE"
			else:
				s1 = "DEFECT"
			if mvs2[i] == True:
				s2 = "COOPERATE"
			else:
				s2 = "DEFECT"
			f.write("\t{0:>20s}\t{1:>20s}\n".format(s1, s2))
		#total scores
		f.write("\t{0:20d}\t{1:20d}\n".format(score1, score2))
		f.close()

#Modify this to decide who is in the tournament
#moduleName.ClassName()
#eg. pdFred.Strat()
strats = [pdDiane.PDStrat(),pdTopkis.PDStrat(),pdDavid.PDStrat(),pdOliver.pdStrat(),pdDaniel.PDStrat(),pdKimberly.PDStrat(),pdJoel.PDStrat(),pdAlex.PDStrat(),fs.AlwaysDefect(), fs.RandomStrat(), fs.AlwaysCooperate()]

t = Tournament(strats)
t.runTournament()
