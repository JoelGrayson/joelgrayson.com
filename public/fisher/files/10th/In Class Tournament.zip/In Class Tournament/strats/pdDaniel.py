"""
For all strategies,
 return True for cooperate, 
 return False for defect
"""

class PDStrat:

    def getName(self):
        return "Daniel"


    def getMove(self, mvHist, oppMvHist):
        if len(oppMvHist) == 0: # if the code has not played this opponent yet
            return True # try cooperating
        elif len(oppMvHist) == 1: # if there is only one round played
            if oppMvHist[0] == True: # if they cooperated
                return True # try cooperating again
            return False # otherwise defect
        elif len(oppMvHist) > 1:
            if oppMvHist[-1] == True and oppMvHist[-2] == True: # if the opponent has been cooperating 
                return True # continue cooperating
            elif oppMvHist[-1] == False: # if the opponent has not been cooperating
                return False # defect
            elif oppMvHist[-1] == True and oppMvHist[-2] == False: # if they cooperated last time but not the time before
                return False # defect this time
            elif oppMvHist[-1] == False and oppMvHist[-2] == True: # if they didn't cooperate last time but did the time before
                return True # cooperate this time
        return False # I think that I got all of the cases but if not, just defect

