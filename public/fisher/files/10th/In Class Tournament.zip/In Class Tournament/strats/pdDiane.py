"""
PRISONER'S DILLEMA TOURNAMENT STRATEGY
HOMEWORK DUE 5/3/2022
DIANE LANG
ADVANCED COMPUTER SCIENCE
"""


class PDStrat(object):
	def getName(self):
		return "Diane"

	
	def getMove(self, mvHist, oppMvHist): #get my move
		index = 0
		selfFalseNum = 0 #counter for how may times I've defected against current opponent
		for i in range(len(mvHist)): #for loop that loops through my moves
			
			if mvHist[index] == False: #if I have defected add 1 to the counter
				selfFalseNum = selfFalseNum + 1
			index = index +1
		if selfFalseNum >= 1: #if i have defected at all defect again b/c opponent won't trust me anymore
			return False 

		else: #if I haven't defected (first move against current opp, for example)
			index = 0
			oppTrueNum = 0 #counter for how many times they've cooperated
			oppFalseNum = 0 #counter for how many times they've defected
			for i in range(len(oppMvHist)): #for the length of the opponents moves
				if oppMvHist[index] == True: #if the they cooperated add 1 to the cooperate number
					oppTrueNum = oppTrueNum + 1
				elif oppMvHist[index] == False: #if they've defected add 1 to the defect number
					oppFalseNum = oppFalseNum + 1
				index = index +1
			if oppFalseNum == 0: #if they always cooperate defect because it will give you more points since they never ever defect
				return False 

			elif oppTrueNum > oppFalseNum and oppFalseNum != 0: #if they cooperate most of the time (but not always) cooperate
				return True

			else: #otherwise defect
				return False