class Strat1(object):
	def getName(self):
		return "Strategy 1"

	def getMove(self, mvHist, oppMvHist):
		if False in oppMvHist:
			return False
		return True


class PDStrat(object):
	def getName(self):
		return "Kimberly"

	def getMove(self, mvHist, oppMvHist):
		if False in oppMvHist: #If they've ever defected
			return False #defect
		if len(mvHist) > 1497: #In the case that N is very big,
			return False #I defect and get a few more points
		return True #otherwise, cooperate


class Strat3(object):
	def getName(self):
		return "Strategy 3"

	def getMove(self, mvHist, oppMvHist):
		if False in oppMvHist:
			return False
		if len(mvHist) > 998:
			return False
		return True

