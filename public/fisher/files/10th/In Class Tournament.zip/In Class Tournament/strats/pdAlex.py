

class PDStrat():

	def getName(self):
		return "Alex Salvatore"



	def getMove(self, mvHist, oppMvHist):

		numC = 0 #num cooperate
		for i in range(len(oppMvHist)):
			if oppMvHist[i] == True:
				numC +=1

		numD = len(oppMvHist) - numC #num defect
		
		
		if len(mvHist) == 0: #always start of cooperating
			return True
		elif len(mvHist) == 1: #second turn always defect
			return False

		elif numC == 0: #if they have never cooperated defect
			
			return False

		elif numD == 0: #if they have never defected 
			
			return False

		elif numC > numD * 2: #if they defect more that 2 times cooperate
			
			return False

		elif numC == numD: #if coop and def are equal
			
			return False

		else: #else defect but set true 2 to true
			
			return False


