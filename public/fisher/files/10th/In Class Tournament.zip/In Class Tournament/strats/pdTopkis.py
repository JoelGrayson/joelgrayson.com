import random
class PDStrat():

	def getName(self):
		return "Emily"

	def getMove(self, mvHist, oppMvHist):
		#true if cooperate
		#false if defect

		numCooperate = 0
		numDefect = 0
		#looping through lists to record history
		for i in oppMvHist:
			if i == True:
				numCooperate+=1
			elif i == False:
				numDefect +=1


		if numCooperate <= numDefect:#if they defect more
			return False #defects first round

		elif len(oppMvHist) < 4:#if theyve only played once or twice
		#we don't know for sure what their strategy is
			return False #if they defect, you defect

		elif numCooperate>numDefect: 
			return True #there's a chance that they will say no again, and you can get a 3
			