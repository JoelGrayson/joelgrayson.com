class PDStrat:
	def getName(self):
		return "David"
	
	def getMove(self, mvHist, oppMvHist):
		if len(mvHist) == 0:
			return True
		else:
			return oppMvHist[-1]
