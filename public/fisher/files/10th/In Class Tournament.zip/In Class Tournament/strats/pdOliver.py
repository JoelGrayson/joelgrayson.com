"""
For all strategies,
 return True for cooperate, 
 return False for defect

"""

class pdStrat():

	def __init__(self):
		pass

	def getName(self):
		return "Oliver"

	def getMove(self, mvHist, oppMvHist):
		#if it is the first game of the series, cooperate
		#I was going to defect first, but that did not work at all
		if not oppMvHist:
			return True

		#otherwise, do the last person's move
		#this means in an only defect or only cooperate situation, I get the same number of points as cooperate
		#and a few fewer than defect
		#in a random situation, I do their last move, which has more possibilities
		#when playing against the same thing, it will be very close to each other
		#and tie every time it is only the two of the same one
		return oppMvHist[-1]
