import random

class AlwaysDefect(object):
	def getName(self):
		return "Always Defect"

	def getMove(self, mvHist, oppMvHist):
		return False


class AlwaysCooperate(object):
	def getName(self):
		return "Always Cooperate"

	def getMove(self, mvHist, oppMvHist):
		return True

class RandomStrat(object):
	def getName(self):
		return "Random"

	def getMove(self, mvHist, oppMvHist):
		if random.random() < 0.5:
			return True
		else:
			return False


