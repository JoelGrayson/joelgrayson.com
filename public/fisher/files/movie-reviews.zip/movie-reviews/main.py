# ABOUT: Bag of Words #bag-of-words model

from load_reviews import get_sample
import scipy.sparse as sp
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import joelclui as j
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.svm import LinearSVC
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import mean_squared_error
from sklearn.metrics import f1_score

SEED=4
MAX_FEATURES=9000 #prevent #features >>> #examples

buff=get_sample()
text=buff.text #pandas series
labels=buff.label


# Remove common, meaningless words and punctuation
split=lambda txt : txt.split(' ')
words_to_exclude=['and', 'or', 'the', 'a', 'an', ',', '(', ')', '.', ':', '"', '-']
preprocess=lambda word_list : filter(lambda word : word not in words_to_exclude, word_list)
join=lambda words : ' '.join(words)
composed=lambda doc : join(preprocess(split(doc))) #function composition

text=list(map(composed, text))

# Split
X_train_words, X_test_words, y_train, y_test=train_test_split(text, labels, test_size=.2, random_state=SEED)
X_train_words, X_valid_words, y_train, y_valid=train_test_split(X_train_words, y_train, train_size=.6/.8, random_state=SEED) #3/4
    # for tuning hyperparameters

# Featurization
def binary():
    vectorizer=CountVectorizer(binary=True, max_features=MAX_FEATURES)
    vectorizer.fit(X_train_words) #gives a unique id to each word and creates vectorizer.vocabulary_
    X_train_vector=vectorizer.transform(X_train_words)
    return X_train_vector, vectorizer

def term_frequency():
    vectorizer=TfidfVectorizer(norm='l2', use_idf=False, smooth_idf=True, sublinear_tf=False, max_features=MAX_FEATURES)
    X_train_vector=vectorizer.fit_transform(X_train_words) #term frequency
    return X_train_vector, vectorizer

def tf_idf():
    transformer=TfidfVectorizer(norm='l2', use_idf=True, smooth_idf=True, sublinear_tf=False, max_features=MAX_FEATURES)
    X_train_vector=transformer.fit_transform(X_train_words) #term frequency * idf
    return X_train_vector, transformer

X_train_vector, vectorizer=binary() #feature vector is a preprocessed X_train_words
X_valid_vector=vectorizer.transform(X_valid_words)


def find_best_C():
    cs=[]
    f_scores=[]

    for C in np.linspace(0.00001, 0.01, 100):
        # Model Creation (Transform)
        clf=LinearSVC(C=C, dual=False) #dual sets optimization problem to dual or primal
        clf.fit(X_train_vector, y_train)


        # Run on Test
        X_test_vector=vectorizer.transform(X_test_words)
        y_pred=clf.predict(X_test_vector)


        # Evaluate
        mse=mean_squared_error(y_test, y_pred)
        f_score=f1_score(y_test, y_pred)
        print(f'{C=:10} {mse=:10} {f_score:10}')
        cs.append(C)
        f_scores.append(f_score)

    plt.plot(cs, f_scores)
    plt.title('Finding the best C')
    plt.xlabel('C')
    plt.ylabel('f_score')
    plt.show()


    """
    # Finding the best order of magnitude
    cs=[]
    f_scores=[]

    for p in range(-10, 10):
        C=10**p
        # Model Creation (Transform)
        clf=LinearSVC(C=C, dual=False) #dual sets optimization problem to dual or primal
        clf.fit(X_train_vector, y_train)


        # Run on Test
        X_test_vector=vectorizer.transform(X_test_words)
        y_pred=clf.predict(X_test_vector)


        # Evaluate
        mse=mean_squared_error(y_test, y_pred)
        f_score=f1_score(y_test, y_pred)
        print(f'{C=:10} {mse=:10} {f_score:10}')
        cs.append(p)
        f_scores.append(f_score)

    plt.plot(cs, f_scores)
    plt.title('Finding the best C')
    plt.xlabel('Order of Magnitude of C')
    plt.ylabel('f_score')
    plt.show()
    """


# Model Creation (Transform)
clf=LinearSVC(C=.0062, dual=False) #dual sets optimization problem to dual or primal
X_train_valid_vector=sp.vstack([X_train_vector, X_valid_vector]) #combine training and validation vector
y_train_valid=pd.concat([y_train, y_valid])
clf.fit(X_train_valid_vector, y_train_valid)


# Run on Test
X_test_vector=vectorizer.transform(X_test_words)
y_pred=clf.predict(X_test_vector)

def prompt():
    while True:
        print('> ', end='')
        u_input=input().strip()
        u_input_vector=vectorizer.transform([u_input])
        res=clf.predict(u_input_vector)
        if res[0]==1:
            j.print('[green]Positive[/]')
        elif res[0]==-1:
            j.print('[red]Negative[/]')

prompt()

# Evaluate
mse=mean_squared_error(y_test, y_pred)
f_score=f1_score(y_test, y_pred)
print(f'{mse=} {f_score=}')

