import os
import numpy as np 
import pandas as pd

def load_directory(dir):
	samples = []
	#for each filename in directory
	for filename in os.listdir(dir):
		path = dir + "/" + filename
		with open(path, 'r') as f: #open file
			#append text of file to list
			samples.append( f.read() )

	return samples

def get_sample():
	pos = load_directory("data/pos")	
	neg = load_directory("data/neg")

	X = pos+neg
	y = np.concatenate((np.ones(len(pos)), -np.ones(len(neg))))

	return pd.DataFrame({'text': X, 'label': y})

