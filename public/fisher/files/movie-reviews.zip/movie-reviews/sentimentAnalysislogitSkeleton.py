import os
import numpy as np 
import pandas as pd
from sklearn.metrics import log_loss, f1_score, accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.svm import LinearSVC


#Same loding code as before
def load_directory(dir):
    samples = []
    #for each filename in directory
    for filename in os.listdir(dir):

        path = dir + "/" + filename
        with open(path, 'r') as f: #open file
            #append text of file to list
            samples.append( f.read() )

    return samples

def get_sample():
    pos = load_directory("data/pos")    
    neg = load_directory("data/neg")


    X = pos+neg
    y = np.concatenate((np.ones(len(pos)), -np.ones(len(neg))))

    return pd.DataFrame({'text': X, 'label': y})

data = get_sample()

# using this method of train test split to more easily
# recover the original text of reviews
sample = data.sample(frac = 1.0, random_state= 11)

X = sample['text'].to_numpy()
y = sample['label'].to_numpy()

#Train Test Split
t_count = int(0.6*len(X))
v_count = int(0.8*len(X))

X_train_words = X[:t_count]
X_val_words = X[t_count:v_count]
X_test_words = X[v_count:]

y_train = y[:t_count]
y_val = y[t_count:v_count]
y_test = y[v_count:]

# TODO: Use your best performing featurizer from the previous assignment
# to vectorize the reviews
transformer=TfidfVectorizer(norm='l2', use_idf=True, smooth_idf=True, sublinear_tf=False, max_features=900) #prevent #features >>> #examples
X_train_vector=transformer.fit_transform(X_train_words) #term frequency * idf
X_test_vector=transformer.transform(X_test_words)


# TODO: Fit a Logistic Regression Model to the data
# You will need to perform hyper parameter tuning
# on the 'C' regularization parameter for logistic regression
# IMPORTANT: Tune C to produce the lowest LOG_LOSS (not f1)

C=100 #best C for TD-IDF
clf=LogisticRegression(C=C)
clf.fit(X_train_vector, y_train)


# TODO: When you have your best C, refeaturize 
# and retrain your model using that C on a combine
# training and validation set. 
# retrain vocab on train + val
# Combining is done for you
X_trainval_vector=transformer.transform(X[:v_count])
y_trainval = y[:v_count]


# Model Creation (Transform)

C=4 #Best C for tf-idf and logistic regression

clf=LogisticRegression(C=C, dual=False, max_iter=1000)
clf.fit(X_train_vector, y_train)


# Run on Test
X_test_vector=transformer.transform(X_test_words)
y_pred=clf.predict(X_test_vector)


# Evaluate
loss=log_loss(y_test, y_pred)


# TODO: Predict the labels and probabilities 
# of the test set. Compute the f1_score, accuracy, 
#   and log_loss of the test set.
# You must use the variable names predictions and 
# probs for the code at the bottom to work.
predictions=clf.predict(X_test_vector)
probs=clf.predict_proba(X_test_vector)
f1_score_res=f1_score(y_test, predictions)
accuracy_score_res=accuracy_score(y_test, predictions)
print(f'{f1_score_res=} {accuracy_score_res=}')
# f1_score_res=0.81 accuracy_score_res=0.81

# TODO: when ready, uncomment this to show the actual test data 
# and predictions to analyze.
# Iterates through all test samples
# Prints review, predicted probability and label


for test_sample in range(len(y_test)):

    print(sample['text'].iloc[v_count + test_sample])

    print(f'Test sample #{test_sample}')
    print(f'True label: {y_test[test_sample]}')
    print(f'Predicted label: {predictions[test_sample]}')
    print(f'Predicted probability: {probs[test_sample]}')


