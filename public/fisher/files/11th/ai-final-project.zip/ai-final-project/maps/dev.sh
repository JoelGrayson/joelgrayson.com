#!/bin/bash

clear
ipython3 -i ./main.py
