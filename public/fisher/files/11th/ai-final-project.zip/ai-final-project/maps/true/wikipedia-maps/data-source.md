These maps are from:
2008 - http://www-personal.umich.edu/~mejn/election/2008/
2020 - https://en.wikipedia.org/wiki/2020_United_States_presidential_election
