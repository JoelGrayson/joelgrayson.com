from data_2010_2012 import data_2010_2012
from data_2020 import data_2020

data_2010_2012()
data_2020()
