* Make maps comparing predicted and actual
