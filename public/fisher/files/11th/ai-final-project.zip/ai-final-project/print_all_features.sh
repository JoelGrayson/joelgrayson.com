#!/bin/bash

clear
python3 preprocessing/print_all_features.py | uniq
