from sklearn import cluster
import seaborn as sns
from matplotlib import pyplot as plt


def elbow(df, x, y):
    # Test where k=1-10
    ks=list(range(1, 10, 1))
    sses=[None for i in range(len(ks))] #sum of square errors
    for ki, k in enumerate(ks):
        sses[ki]=cluster.KMeans(n_clusters=k, init='k-means++', n_init='auto').fit(df[[x, y]]).inertia_ #inertia is the sum of all the square distances between the points
            # source: https://www.codecademy.com/learn/machine-learning/modules/dspath-clustering/cheatsheet
    
    # Plot the elbow method
    fig, ax=plt.subplots()
    ax.plot(ks, sses)
    ax.set_title(f'Elbow method for "{x}" vs "{y}"')
    plt.show()


def elbow_more_than_2(df, clusters):
    # Test where k=1-10
    ks=list(range(1, 10, 1))
    sses=[None for i in range(len(ks))] #sum of square errors
    for ki, k in enumerate(ks):
        sses[ki]=cluster.KMeans(n_clusters=k, init='k-means++', n_init='auto').fit(df[clusters]).inertia_ #inertia is the sum of all the square distances between the points
            # source: https://www.codecademy.com/learn/machine-learning/modules/dspath-clustering/cheatsheet
    
    # Plot the elbow method
    fig, ax=plt.subplots()
    ax.plot(ks, sses)
    ax.set_title(f'Elbow method for many features')
    plt.show()
