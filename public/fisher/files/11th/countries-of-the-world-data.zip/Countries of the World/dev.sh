#!/bin/bash

clear
echo '--------'
ipython3 -i main.py
