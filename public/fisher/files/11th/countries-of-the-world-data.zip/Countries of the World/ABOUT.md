# Files
* `raw countries of the world.csv` is from [kaggle](https://www.kaggle.com/datasets/fernandol/countries-of-the-world)
* `countries of the world.csv` is preprocessed using `preprocess.py`

## TODO
- [ ] Run with more than 2 dimensions


## Preprocessing About
Region - one-hot
Climate - one-hot
Literacy (%) - /100
Arable (%) - /100
Crops (%) - /100
Infant mortality (per 1000 births) - /1000
Phones (per 1000) - /1000
Birthrate - /1000 to become births per person per year
Deathrate - /1000
Population - standardize
Area (sq. mi.) - standardize
Pop. Density (per sq. mi.) - standardize
Coastline (coast/area ratio) - standardize
Net migration - standardize
GDP ($ per capita) - standardize
Agriculture - 👍
Industry - 👍


## About the Columns
Area - in square miles
Deathrate - how many of 1000 people die every year

Raw column names=['Region', 'Population', 'Area (sq. mi.)', 'Pop. Density (per sq. mi.)',
'Coastline (coast/area ratio)', 'Net migration',
'Infant mortality (per 1000 births)', 'GDP ($ per capita)',
'Literacy (%)', 'Phones (per 1000)', 'Arable (%)', 'Crops (%)',
'Climate', 'Birthrate', 'Deathrate', 'Agriculture', 'Industry',
'Service']

Preprocessed column names=['Population', 'Area', 'Population Density', 'Coastline',
'Net migration', 'Infant mortality', 'GDP per capita', 'Literacy',
'Phones', 'Arable', 'Crops', 'Birthrate', 'Deathrate', 'Agriculture',
'Industry', 'Service', 'Region-is-ASIA (EX. NEAR EAST)',
'Region-is-BALTICS', 'Region-is-C.W. OF IND. STATES',
'Region-is-EASTERN EUROPE', 'Region-is-LATIN AMER. & CARIB',
'Region-is-NEAR EAST', 'Region-is-NORTHERN AFRICA',
'Region-is-NORTHERN AMERICA', 'Region-is-OCEANIA',
'Region-is-SUB-SAHARAN AFRICA', 'Region-is-WESTERN EUROPE',
'Climate-is-1.0', 'Climate-is-1.5', 'Climate-is-2.0', 'Climate-is-2.5',
'Climate-is-3.0', 'Climate-is-4.0']
