from sklearn import cluster
import seaborn as sns
from matplotlib import pyplot as plt

def compare(df, x, y, n_clusters, show_normalized=False):
    kmeans=cluster.KMeans(n_clusters=n_clusters, init='k-means++', n_init='auto')
    res=kmeans.fit(df[[x, y]])
    df['Clusters']=res.labels_
    to_plot=df[[x, y, 'Clusters']]
    # sns.set_style('darkgrid')

    if show_normalized: #top is one-to-one, bottom has normalized scaling
        fig, ax=plt.subplots(nrows=2, ncols=1)
        sns.scatterplot(data=to_plot, x=x, y=y, hue='Clusters', ax=ax[0])
        sns.scatterplot(data=to_plot, x=x, y=y, hue='Clusters', ax=ax[1])
        ax[0].set_xlim(0, 1)
        ax[0].set_ylim(0, 1)
        fig.set_figheight(7)
        fig.set_figwidth(5)
    else:
        fig, ax=plt.subplots(nrows=1, ncols=1)
        sns.scatterplot(data=to_plot, x=x, y=y, hue='Clusters', ax=ax)
        ax.set_title(f'Correlation between "{x}" and "{y}"')

    plt.show()

def compare_more_than_2(df, clusters, n_clusters): #clusters :: [string]
    kmeans=cluster.KMeans(n_clusters=n_clusters, init='k-means++', n_init='auto')
    res=kmeans.fit(df[clusters])
    df['Clusters']=res.labels_
    result=df[[*clusters, 'Clusters']]
    cluster_data=[result[result.Clusters==i] for i in range(n_clusters)]
    return cluster_data

