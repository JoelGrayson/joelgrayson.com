import pandas as pd
from convert_to_floats import convert_to_floats

df=pd.read_csv('./normalized countries of the world.csv', decimal=',') #type: ignore
convert_to_floats(df)
