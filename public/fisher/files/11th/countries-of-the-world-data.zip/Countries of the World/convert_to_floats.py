def convert_to_floats(df):
    converting_to_int=['Population', 'Area', 'Population Density', 'Coastline', 'Net migration', 'Infant mortality', 'GDP per capita', 'Literacy', 'Phones', 'Arable', 'Crops', 'Birthrate', 'Deathrate', 'Agriculture', 'Industry', 'Service']
    df[converting_to_int]=df[converting_to_int].astype(float)
