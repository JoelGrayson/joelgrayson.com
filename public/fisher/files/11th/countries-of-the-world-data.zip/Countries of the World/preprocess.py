import pandas as pd
from convert_to_floats import convert_to_floats

#* # Correct columns and rows
df=pd.read_csv('./raw countries of the world.csv', decimal=',')\
    .drop(['Country', 'Other (%)'], axis=1)\
    .dropna()\
    .rename(columns={
        'Area (sq. mi.)': 'Area',
        'Pop. Density (per sq. mi.)': 'Population Density',
        'Coastline (coast/area ratio)': 'Coastline',
        'Infant mortality (per 1000 births)': 'Infant mortality',
        'GDP ($ per capita)': 'GDP per capita',
        'Phones (per 1000)': 'Phones',
        'Literacy (%)': 'Literacy',
        'Arable (%)': 'Arable',
        'Crops (%)': 'Crops',
    })

# Convert from strings to integers
convert_to_floats(df)

#* # Preprocessing 1 (for meaningful data, which is in scale) (e.g. one tick means 1 death per million)
#* ## One-hot encoding
one_hot=pd.get_dummies(df['Region'], prefix='Region-is', prefix_sep='-')
df=df\
    .drop(['Region'], axis=1)\
    .join(one_hot)\
    .rename(columns=lambda x:x.strip())
one_hot=pd.get_dummies(df['Climate'], prefix='Climate-is', prefix_sep='-')
df=df\
    .drop(['Climate'], axis=1)\
    .join(one_hot)\
    .rename(columns=lambda x:x.strip())


#* ## Linear scaling (using standardization so countries with small values have distinctions by orders of magnitudes)
for column_name in ['Literacy', 'Arable', 'Crops']: #%
    df[column_name]/=100
for column_name in ['Infant mortality', 'Phones', 'Birthrate', 'Deathrate']: #per 1000
    df[column_name]/=1000

for column_name in ['Population', 'Area', 'Population Density', 'Coastline', 'Net migration', 'GDP per capita']:
    df[column_name]-=df[column_name].mean(axis=0)
    df[column_name]/=df[column_name].std(axis=0)


#* ## Saving
df.to_csv('./countries of the world.csv', index=False)


#* # Preprocessing 2 (normalization and standrdization for meaningful clustering, scale between factors is not preserved)
standardized_df=df.copy()
normalized_df=df.copy()
for column_name in ['Population', 'Area', 'Population Density', 'Coastline', 'Net migration', 'Infant mortality', 'GDP per capita', 'Literacy', 'Phones', 'Arable', 'Crops', 'Birthrate', 'Deathrate', 'Agriculture', 'Industry', 'Service']:
    col=df[column_name]
    standardized_df[column_name]-=col.mean()
    standardized_df[column_name]/=col.std()

    min=col.min()
    max=col.max()
    normalized_df[column_name]-=min
    normalized_df[column_name]/=max-min

standardized_df.to_csv('./standardized countries of the world.csv', index=False)
normalized_df.to_csv('./normalized countries of the world.csv', index=False)

