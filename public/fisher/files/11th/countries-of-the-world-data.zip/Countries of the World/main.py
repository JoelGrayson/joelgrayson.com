import pandas as pd
from convert_to_floats import convert_to_floats
from compare import compare, compare_more_than_2
from elbow import elbow, elbow_more_than_2

df=pd.read_csv('./normalized countries of the world.csv', decimal=',') #type: ignore
standard_df=pd.read_csv('./standardized countries of the world.csv', decimal=',') #type: ignore
convert_to_floats(df)
convert_to_floats(standard_df)

compare(df, 'Literacy', 'Birthrate', 3) #analysis: Literacy correlates with lower birth rates
compare(df, 'Literacy', 'Birthrate', 3) #analysis: Literacy correlates with lower birth rates
compare(df, 'Phones', 'Deathrate', 5) #analysis: more phones means less deathrate because higher socioeconomic status


testing_cols=['Population', 'Area', 'Population Density', 'Coastline',
'Net migration', 'Infant mortality', 'GDP per capita', 'Literacy',
'Phones', 'Arable', 'Crops', 'Birthrate', 'Deathrate', 'Agriculture', 'Industry', 'Service']
result=compare_more_than_2(df, testing_cols, 3)
for res in result:
    print(len(res))
    print(res.mean())

elbow_more_than_2(df, testing_cols)

# Analysis: Oceanic countries have a larger coastline
print("Oceanic countries' average coastline:",     df[df['Region-is-OCEANIA']==1].Coastline.mean())
print("Non-Oceanic countries' average coastline:", df[df['Region-is-OCEANIA']==0].Coastline.mean())
compare(df, 'Region-is-OCEANIA', 'Coastline', 3)

compare(df, 'Birthrate', 'Deathrate', 3) #analysis: more phones means less deathrate because higher socioeconomic status

compare(df, 'GDP per capita', 'Service', 3) #analysis: more phones means less deathrate because higher socioeconomic status
compare(df, 'GDP per capita', 'Industry', 3) #analysis: more phones means less deathrate because higher socioeconomic status
compare(df, 'GDP per capita', 'Agriculture', 3) #analysis: more phones means less deathrate because higher socioeconomic status

# Elbow method for birthrate and deathrate
elbow(df, 'Birthrate', 'Deathrate')
elbow(df, 'Literacy', 'Birthrate')
