#* About: Lets you type sentences

import joelclui as j

from pynput.keyboard import Key, Listener
import sys
sys.path.append('helpers')
from autocomplete import autocomplete
from split_on_current_word import split_on_current_word

MAX_SUGGESTIONS=3

u_input=''
suggestions=[]

def main():
    # <Helpers>
    def complete_suggestion(index):
        global u_input
        u_input=split_on_current_word(u_input)[0]+suggestions[index]+' '

    def clear_screen():
        for i in range(MAX_SUGGESTIONS+1):
            print(' '*60)
        j.move_up(MAX_SUGGESTIONS+1)
    
    def display(): #shows user's input and suggestions
        global suggestions

        print(u_input or '', end='')
        j.print('[blue][bold]|[/]') #artificial cursor

        suggestions=autocomplete(split_on_current_word(u_input)[1], MAX_SUGGESTIONS)
        if suggestions!=[] and suggestions!=None:
            for i, suggestion in enumerate(suggestions):
                j.print(f'[blue]{i+1}[/] {suggestion}')
            j.move_up(len(suggestions))
        j.move_up()
    # </>
    
    def on_press(key):
        global u_input

        if key==Key.backspace and u_input!="": #delete
            u_input=u_input[:-1] #cut off the last char
        elif key==Key.tab: #tab completion
            complete_suggestion(0)
        elif key==Key.enter:
            print(u_input)
            u_input=''
        elif key==Key.esc:
            return False
        elif key==Key.space:
            u_input+=' '
        elif hasattr(key, 'char'): #add character
            char=key.char
            number_triggered=False

            for i in range(MAX_SUGGESTIONS): #array is zero-indexed, show user one-indexed
                if char==str(i+1) and suggestions[i] is not None:
                    complete_suggestion(i)
                    number_triggered=True
            
            if not number_triggered: #regular character
                u_input+=char
                if u_input[-5:].lower()=='$quit': #quit
                    return False
        
        clear_screen()
        display()

    with Listener(suppress=True, on_press=on_press) as listener:
        listener.join()

j.print('---[bold]Autocompleter[/]---')
j.print('Press [red]escape[/] or type [red]$quit[/] to exit')
j.print('Press the number to select a word\n')

j.print('[blue]Enter some text...[/]')
j.move_up()
main()
