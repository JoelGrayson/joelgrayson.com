# Only read the file once
f=open('./commonWords.txt')
lines=f.readlines() #get contents in array of lines
lines=list(map(lambda line : line.strip(), lines)) #strip the newlines
f.close()

def autocomplete(part, MAX_SUGGESTIONS):
    if part=='': return #do not autocomplete nothing

    recommendations=[]
    for item in lines:
        firstPartOfWord=item[0:len(part)]
        if firstPartOfWord==part:
            recommendations.append(item)
    return recommendations[:MAX_SUGGESTIONS]
