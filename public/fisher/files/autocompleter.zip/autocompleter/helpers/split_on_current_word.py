def split_on_current_word(u_input): #'hi world bye' -> ['hi world ', 'bye'], 'hi' -> ['hi']
    for i in range(len(u_input)-1, 0, -1): #find last space
        if u_input[i]==' ':
            return [u_input[:i+1], u_input[i+1:]] #return everything after last space
    return ['', u_input] #if no spaces, return entire thing
