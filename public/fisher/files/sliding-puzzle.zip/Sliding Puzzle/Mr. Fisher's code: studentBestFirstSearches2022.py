from typing import Literal
import numpy as np
import random
from collections import deque
from heapq import heappop, heappush
BOARDSIZE = 3
from time import time as t


"""
##############
Implement Heuristics here
 1) Sum Manhattan distances between pieces and correct locations
 2) Hamming Distance: number of tiles out of place.

"""
def index_of(board, value):
	rows, cols=board.shape
	for row in range(rows):
		for col in range(cols):
			if board[row, col]==value:
				return row, col
	raise Exception('Not found')


def manhattan(board, goal) -> int:
	num_off=0
	for row in range(BOARDSIZE):
		for col in range(BOARDSIZE):
			value=board[row, col]
			# Where it is supposed to be in a goal board
			goal_row=(value-1)//3
			goal_col=(value-1)%3

			num_off+=abs(row-goal_row)+abs(col-goal_col)
	return num_off

def manhattan_old(board, goal) -> int:
	num_off=0
	for row in range(BOARDSIZE):
		for col in range(BOARDSIZE):
			goal_row, goal_col=index_of(goal, board[row, col])
			num_off+=abs(row-goal_row)+abs(col-goal_col) #type: ignore
	return num_off


def hamming(board, goal) -> int:
	flat_board=board.flatten()
	flat_goal=goal.flatten()

	num_off=0
	for i in range(len(flat_board)):
		if flat_board[i] != flat_goal[i]:
			num_off+=1
	return num_off

# How do we represent the board/ current state of puzzle

# np.arange(start, stop, step) gives you a 1d array of values 
# beginning with start, counting by step up to stop(exclusive)

#0 -> empty spot
def createBoard():
	board = np.arange(1,BOARDSIZE**2+1,1)

	board = board.reshape((BOARDSIZE, BOARDSIZE))
	board[-1,-1] = 0 #put blank in last spot
	return board

# How do we check if we are in the goal state?
def checkGoal(board):
	goal = createBoard()
	#option 1 - .all() returns True if all values in the array are True
	#print((board == goal).all())

	#option2
	return np.array_equal(board, goal)

	#option3 - convert to strings
	#print(str(goal) == str(board))


# How do we know what moves are available?
# (what are the children of current state)
	# - need to know where the 0 is

def findZero(board):
	#find the 0
	loc = np.where(board==0)
	# returns as a tuple
	return loc[0][0], loc[1][0]

	# rows, cols = board.shape
	# for i in range(rows):
	# 	for j in range(cols):
	# 		if board[i,j] == 0:
	# 			return i,j # return loc of 0



def legalMoves(board):
	zeroR, zeroC = findZero(board)

	#create a list of legal moves
	# e.g. ['down', 'right']
	# OR    [(1,2), (2,1)]

	moves = []
	if zeroR > 0:
		moves.append((zeroR - 1, zeroC)) # down
	if zeroR < BOARDSIZE - 1:
		moves.append((zeroR + 1, zeroC)) # up
	if zeroC > 0:
		moves.append((zeroR, zeroC - 1)) # right
	if zeroC < BOARDSIZE - 1:
		moves.append((zeroR, zeroC + 1)) # left

	# returns a list of legal moves AKA children
	return moves

	# using zero and the BOARDSIZE

# How do we represent a change in state/how do we make a move?
#performs the move on the given board
#does not error check
#modifies the board passed in
def move(board, move):
	r,c = findZero(board)

	board[r,c] = board[move]
	board[move] = 0



# How do we create a randomized puzzle to solve?

def scramble(board, numMoves, seed=None):
	if seed is not None:
		random.seed(seed)
	
	#do a bunch of random legal moves
	n = board.shape[0]
	
	for i in range(numMoves):
		moves = legalMoves(board)
		mv = random.choice(moves)
		move(board, mv)




#Execute Breadth-first Search to solve puzzle
def BFS(puzzle):
	goal = createBoard() 
	goalStr = str(goal) #for checking if a board is solved

	#Double Ended Queue - O(1) enqueue and dequeue
	frontier = deque()
	frontier.append(puzzle.copy())

	# explored states - A python SET
	# Using STRINGS b/c arrays are mutable and thus not valid keys
	

	visited = {str(puzzle): []}

	while frontier: #while not empty

		# FIFO: pop from left
		# Get state from frontier
		board = frontier.popleft()
		mvList = visited[str(board)]

		#for each legal move
		for mv in legalMoves(board):
			testBoard = board.copy() #copy board to avoid modifying it

			move(testBoard, mv) #make move

			boardStr = str(testBoard)
			#if we haven't already explored this new state
			if boardStr not in visited:

				#checking if popped state is goal
				if goalStr == boardStr:
					return mvList + [mv]

				# Add to frontier (at back)
				frontier.append(testBoard)
	
				# Add child to visited dictionary
				visited[boardStr] = mvList + [mv]

#Execute Best-firstSearch to solve puzzle
def Greedy_Best_First_Search(puzzle, heuristic: Literal['manhattan'] | Literal['hamming']='manhattan'):
	goal = createBoard() 
	goalStr = str(goal) #for checking if a board is solved

	frontier = [] #heapq is stored as a list
	counter = 0 #break ties in heapq

	"""
	#############################
	compute score of initial state 
	according to Greedy Best First Algorithm
	CHANGE function to switch heuristic

	"""
	heuristic_func=manhattan
	if heuristic == 'manhattan':
		heuristic_func = manhattan
	if heuristic == 'hamming':
		heuristic_func = hamming
	
	score = heuristic_func(puzzle, goal)


	#heapq functions take queue as param and modify it
	#frontier is a priority queue
	#Tuple contains evaluation score and a counter to break ties
	#in priority. Also stores move history and actual puzzle state
	heappush(frontier, (score, counter, [], puzzle.copy()))



	# visited states - A python SET
	# Using STRINGS b/c arrays are mutable and thus not valid keys

	visited = set(str(puzzle))

	while frontier: #while not empty



		state = heappop(frontier)
		mvList = state[2] #get move history from frontier
		board = state[3] #get board from frontier


		# We check goal AFTER removing from queue to guarantee  
		# we have foudn the shortest path to that node
		boardStr = str(board)
		if goalStr == boardStr:
			return mvList


		#for each legal move
		for mv in legalMoves(board):
			testBoard = board.copy() #copy board to avoid modifying it

			move(testBoard, mv) #make move

			#if we haven't already explored this new state
			if str(testBoard) not in visited:
				counter += 1
				"""
				Greedy BFS
				f(n) = h(n)
				i.e. Priority = heuristic
				CHANGE function to switch heuristic
				"""
				score = heuristic_func(testBoard, goal)
				heappush(frontier, (score,counter, mvList + [mv], testBoard))
	
		# Add board to visited set
				
		visited.add(boardStr) 


	return "NO SOLUTION"

#Execute A* Search to solve puzzle
def A_Star_Search(puzzle, heuristic: Literal['manhattan'] | Literal['hamming']='manhattan'):
	goal = createBoard() 
	goalStr = str(goal) #for checking if a board is solved

	frontier = [] #heapq is stored as a list
	counter = 0 #break ties in heapq

	"""
	#############################
	compute score of initial state 
	according to A*
	CHANGE function to switch heuristic
	"""
	heuristic_func=manhattan
	if heuristic == 'manhattan':
		heuristic_func = manhattan
	if heuristic == 'hamming':
		heuristic_func = hamming
	
	score = heuristic_func(puzzle, goal)


	#heapq functions take queue as param and modify it
	#frontier is a priority queue
	#Tuple contains evaluation score and a counter to break ties
	#in priority. Also stores move history and actual puzzle state
	heappush(frontier, (score, counter, [], puzzle.copy()))



	# explored states - A python SET
	# Using STRINGS b/c arrays are mutable and thus not valid keys
	

	visited = set(str(puzzle))

	while frontier: #while not empty



		state = heappop(frontier)
		mvList = state[2] #get move history from frontier
		board = state[3] #get board from frontier


		# We check goal AFTER removing from queue to guarantee  
		# we have foudn the shortest path to that node
		boardStr = str(board)
		if goalStr == boardStr:
			return mvList


		#for each legal move
		for mv in legalMoves(board):
			testBoard = board.copy() #copy board to avoid modifying it

			move(testBoard, mv) #make move

			#if we haven't already explored this new state
			if str(testBoard) not in visited:
				counter += 1
				"""
				A*
				f(n) = g(n) + h(n)
				i.e. Priority = cost so far + heuristic
				CHANGE function to switch heuristic
				"""
				score = heuristic_func(testBoard, goal) + len(mvList) + 1
				heappush(frontier, (score,counter, mvList + [mv], testBoard))
	
		# Add board to visited set		
		visited.add(boardStr) 


	return "NO SOLUTION"



#Call this function on the starting board and 
#the list of moves returned by the algorithm
def reconstructSolution(board, mvList):
	for mv in mvList:
		zr, zc = findZero(board)
		mr, mc = mv
			
		if zr > mr:
			print("down")
		elif zr < mr:
			print("up")
		elif zc > mc:
			print("right")
		else:
			print("left")

		move(board, mv)
		print(board)
	print(f"Total Moves:{len(mvList)}")



def main():
	goal = createBoard()
	start = goal.copy() # For use in reconstructSolution
	board = goal.copy()

	# Remember to choose the number of scrambling moves.
	# If you would like to generate the same board multiple times
	# you should SEED the random number generator.
	scramble(board, 100)


	####
	"""
	Test the Algorithms here. Call search algorithms on board
	Then call reconstruct solution with start on the returned 
	move list
	"""
	###

	start=t()
	print(A_Star_Search(board, heuristic='manhattan'))
	print(f'A* took: {t()-start: .2f} seconds')
	start=t()
	print(Greedy_Best_First_Search(board, heuristic='manhattan'))
	print(f'Greedy took: {t()-start: .2f} seconds')





if __name__ == '__main__':
	main()
