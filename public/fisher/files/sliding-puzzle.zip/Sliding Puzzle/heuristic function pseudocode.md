## Manhattan Distance


## Hamming Distance








# My Heuristic Function Brainstorming

## 1. Sum of Distances between Squares
[[0 1 6]       [[1 2 3]
 [7 3 2]   ->   [4 5 6]
 [5 4 8]]       [7 8 0]]

See the distances between where each square is to where it is supposed to go (target). Add up all the distances.

### Pseudocode
```rs
let current_board, target_board

fn heuristic_distance() -> integer
    dist=0 //estimate of how far away two boards are
    for square in 1..9
        curr_index=current_board.find_index(square)
        target_index=target_board.find_index(square)
        dist+=abs(curr_index[0]-target_index[0])+abs(curr_index[1]-target_index[1]) //distance between current and target indices
    return dist
```


## 2. How Many Squares in Right Position

Return how many squares are in target position

### Pseudocode
```rs
let current_board, target_board

fn heuristic_distance() -> integer
    dist=0 //estimate of how far away two boards are
    for every col
        for every row
            if current_board[col,row]!=target_board[col,row]: //add to distance if not equal
                dist+=1
    return dist
```
