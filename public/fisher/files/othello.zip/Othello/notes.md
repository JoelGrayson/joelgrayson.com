# Notes on a Better Heuristic
* Mobility - being able to move
* Stability - how likely a piece is to stay that way
    * corners are stable
    * edge pieces contiguous with corners
* Corners
* Parity

* Combining
    * Parity is more important towards the end of the game. Mobility is more important towards the start of the game.
