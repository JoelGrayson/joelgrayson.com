square_weights = np.array([  #University of Washington othello board values
 [20, -3, 11, 8, 8, 11, -3, 20], [-3, -7, -4, 1, 1, -4, -7, -3],
 [11, -4, 2, 2, 2, 2, -4, 11], [8, 1, 2, -3, -3, 2, 1, 8],
 [8, 1, 2, -3, -3, 2, 1, 8], [11, -4, 2, 2, 2, 2, -4, 11],
 [-3, -7, -4, 1, 1, -4, -7, -3], [20, -3, 11, 8, 8, 11, -3, 20]
])

def mobility(board, turn):
	mymoves = get_all_moves(board, turn)
	mycount = len(mymoves)
	oppmoves = get_all_moves(board, -turn)
	oppcount = len(oppmoves)

	myCorners = 0
	oppCorners = 0
	if board[0][0] == turn:
		myCorners += 1
	elif board[0][0] == -turn:
		oppCorners += 1
	if board[0][7] == turn:
		myCorners += 1
	elif board[0][7] == -turn:
		oppCorners += 1
	if board[7][0] == turn:
		myCorners += 1
	elif board[7][0] == -turn:
		oppCorners += 1
	if board[7][7] == turn:
		myCorners += 1
	elif board[7][7] == -turn:
		oppCorners += 1
	if mycount > oppcount:
		mob = (100.0 * mycount) / (mycount + oppcount)
	elif mycount < oppcount:
		mob = -(100.0 * oppcount) / (mycount + oppcount)
	else:
		mob = 0
	final = (10 * (myCorners-oppCorners)) + (mob)
	return final
	
	
def heuristic(board,V,turn): #https://play-othello.appspot.com/files/Othello.pdf
	mypieces = 0
	countwhite = 0
	countblack = 0
	opppieces = 0
	rows,cols = board.shape #tuple it out

	for r in range(rows): #loop through
		for c in range(cols):
			if board[r,c] == 1:
				countblack += 1
			if board[r,c] == -1:
				countwhite += 1

	totalcount = countwhite + countblack

	if totalcount < 24:#mobility
		return mobility(board, turn)
	elif totalcount >= 24 and totalcount < 58: #mobility( was supposed to be stability but im bad at coding)
		for r in range(rows): #loop through
			for c in range(cols):
				if board[r,c] == 1:
					mypieces += V[r,c]
				if board[r,c] == -1:
					opppieces += V[r,c]
		return mypieces-opppieces
	elif totalcount >= 58:#absolute
		return board.sum()