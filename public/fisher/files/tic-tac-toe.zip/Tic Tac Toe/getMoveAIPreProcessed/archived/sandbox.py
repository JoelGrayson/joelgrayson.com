from getMoveAIPreProcessed.getMoveAI import getMoveAI
from getMoveAIPreProcessed.helpers import serialize_board, deserialize_board
from main import init_board, show_board, checkWin


# def test(b):
#     print('\n\nBoard:')
#     print(b)
#     print('Serialized:')
#     print(serialize_board(b))
#     print('Deserialized Serialized:')
#     print(deserialize_board(b))

# b=init_board()
# test(b)
# b[1, 0]=1
# test(b)
# b[1, 1]=2
# test(b)
# b[1, 2]=1
# test(b)
# b[2, 0]=2
# test(b)

# b[2, 2]=1
# print(getMoveAI(b, 2))
