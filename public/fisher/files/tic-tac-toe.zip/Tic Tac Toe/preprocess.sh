#!/bin/bash

echo "Preprocessing"
cd getMoveAIPreprocessed
python3 preprocess.py
echo "Done Preprocessing"
