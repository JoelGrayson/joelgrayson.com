# About
Run `python3 main.py` to start the program. You can either play an AI or watch the AI play itself.
Run `./preprocess.sh` for the AI to preprocess its strategy. This will take a few minutes.

# Timing Stats
The pre-processed AI is 70x faster than the real-time AI.

                            Time to play itself
Real-Time (getMoveAI)       29 seconds
getMoveAIOptimized          40 seconds  #ironic
getMoveAIPreprocessed       0.4 seconds ⚡
