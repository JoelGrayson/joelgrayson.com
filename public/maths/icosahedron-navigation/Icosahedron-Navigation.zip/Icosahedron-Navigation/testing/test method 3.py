import sys
sys.path.append('../methods')
from method3 import main as method3

print(method3().analytics_report())
