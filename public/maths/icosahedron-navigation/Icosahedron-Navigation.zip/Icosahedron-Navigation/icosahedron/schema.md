Sides:
    num: num
    mark: String
